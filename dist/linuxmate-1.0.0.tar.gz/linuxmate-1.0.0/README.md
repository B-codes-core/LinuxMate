<h1>Linux Mate</h1>
<p>
Linux Mate is your personal Linux assistant, ready to help you solve your doubts, whether you are beginner or a pro Linux User. LinuxMate leverages the power of Gemini API, made by Google to answer your questions right from your command line interface. Linuxmate is still in development (Current Version 1.0.0), and feel free to suggest any future improvements and/or bug fixes.
</p>
<br>
<h1>Installation Guide</h1>
<ol>
      <li><h2>